package com.ramirez.omikuji.models;

public class OmikujiModel {

}
